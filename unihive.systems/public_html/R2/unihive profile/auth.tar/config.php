<?php
// Database credentials
$hostname = "localhost";
$username = "root";
$password = "";
$database = "project";

// Attempt to connect to MySQL without database first
$conn = mysqli_connect($hostname, $username, $password);

// Check connection
if(!$conn) {
    die("ERROR: Could not connect to MySQL. " . mysqli_connect_error());
}

// Check if database exists, if not create it
$db_check = mysqli_query($conn, "SELECT SCHEMA_NAME FROM INFORMATION_SCHEMA.SCHEMATA WHERE SCHEMA_NAME = '$database'");
if(mysqli_num_rows($db_check) == 0) {
    // Database doesn't exist, create it
    $sql = "CREATE DATABASE $database";
    if(mysqli_query($conn, $sql)) {
        echo "Database created successfully!";
    } else {
        die("ERROR: Could not create database. " . mysqli_error($conn));
    }
}

// Select the database
mysqli_select_db($conn, $database) or die("ERROR: Could not select database. " . mysqli_error($conn));

// After successful connection and database selection, check if users table exists
$table_check = mysqli_query($conn, "SHOW TABLES LIKE 'users'");
if(mysqli_num_rows($table_check) == 0) {
    // Create users table
    $sql = "CREATE TABLE users (
        id INT NOT NULL PRIMARY KEY AUTO_INCREMENT,
        username VARCHAR(50) NOT NULL UNIQUE,
        password VARCHAR(255) NOT NULL,
        email VARCHAR(100) NOT NULL,
        created_at DATETIME DEFAULT CURRENT_TIMESTAMP
    )";
    mysqli_query($conn, $sql) or die("ERROR: Could not create users table. " . mysqli_error($conn));
}
?>
