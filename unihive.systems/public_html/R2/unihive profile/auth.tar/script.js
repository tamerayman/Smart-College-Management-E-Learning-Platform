document.addEventListener('DOMContentLoaded', function() {
    // Toggle menu
    const menuToggle = document.getElementById('menu-toggle');
    const menu = document.getElementById('mean');
    
    if (menuToggle && menu) {
        menuToggle.addEventListener('click', function() {
            menu.classList.toggle('active');
        });
    }
    
    // Toggle profile settings
    const userIcon = document.getElementById('userIcon');
    const profileSettings = document.querySelector('.profile_settings');
    
    if (userIcon && profileSettings) {
        userIcon.addEventListener('click', function() {
            profileSettings.classList.toggle('show');
        });
        
        // Close profile settings when clicking outside
        document.addEventListener('click', function(event) {
            if (!event.target.closest('.user_profile') && !event.target.closest('.profile_settings')) {
                profileSettings.classList.remove('show');
            }
        });
    }
});
