<?php
// Start session
session_start();

// Include database configuration
require_once "config.php";

// Check if the user is logged in, if not redirect to login page
function checkLogin() {
    if(!isset($_SESSION["loggedin"]) || $_SESSION["loggedin"] !== true){
        header("location: login.php");
        exit;
    }
}

// Get user data from database
function getUserData($userId) {
    global $conn;
    $sql = "SELECT * FROM users WHERE id = ?";
    
    if($stmt = mysqli_prepare($conn, $sql)){
        mysqli_stmt_bind_param($stmt, "i", $userId);
        
        if(mysqli_stmt_execute($stmt)){
            $result = mysqli_stmt_get_result($stmt);
            
            if(mysqli_num_rows($result) == 1){
                return mysqli_fetch_assoc($result);
            }
        }
        mysqli_stmt_close($stmt);
    }
    return false;
}

// Logout function
function logoutUser() {
    // Unset all session variables
    $_SESSION = array();
    
    // Destroy the session
    session_destroy();
    
    // Redirect to login page
    header("location: login.php");
    exit;
}
?>