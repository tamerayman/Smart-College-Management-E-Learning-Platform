<?php
// معلومات الاتصال بقاعدة البيانات
$host = "localhost";
$username = "root";
$password = "";
$database = "project";

// دالة إنشاء اتصال بقاعدة البيانات وإرجاع الاتصال
function connectDB() {
    global $host, $username, $password, $database;
    
    // إنشاء اتصال
    $conn = new mysqli($host, $username, $password, $database);
    
    // التحقق من الاتصال
    if ($conn->connect_error) {
        die("فشل الاتصال بقاعدة البيانات: " . $conn->connect_error);
    }
    
    // تعيين ترميز الاتصال
    $conn->set_charset("utf8mb4");
    
    return $conn;
}

// إنشاء متغير اتصال للاستخدام المباشر إذا لزم الأمر
$conn = connectDB();
?>