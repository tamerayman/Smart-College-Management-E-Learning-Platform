<?php
// filepath: d:\wamp64\www\R2\unihive profile\get_profile.php

require_once 'db_connect.php';
require_once 'auth.php';

// التحقق من تسجيل الدخول
checkAuth();

// استعلام لجلب بيانات المستخدم
function getUserData($userId) {
    global $conn;
    
    $stmt = $conn->prepare("SELECT users.*, 
                          student_info.level, 
                          student_info.department 
                          FROM users 
                          LEFT JOIN student_info ON users.id = student_info.user_id 
                          WHERE users.id = ?");
    $stmt->bind_param("i", $userId);
    $stmt->execute();
    $result = $stmt->get_result();
    
    if ($result->num_rows > 0) {
        return $result->fetch_assoc();
    } else {
        return null;
    }
}

// إذا تم استدعاء الملف من خلال AJAX، أعد البيانات كـ JSON
if (isset($_SERVER['HTTP_X_REQUESTED_WITH']) && strtolower($_SERVER['HTTP_X_REQUESTED_WITH']) === 'xmlhttprequest') {
    $userId = getCurrentUserId();
    $userData = getUserData($userId);
    
    header('Content-Type: application/json');
    echo json_encode($userData);
    exit();
}
?>