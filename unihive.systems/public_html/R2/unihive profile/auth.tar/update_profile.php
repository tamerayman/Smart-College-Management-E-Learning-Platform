<?php
require_once 'db_connect.php';
require_once 'auth.php';

// التحقق من تسجيل الدخول
checkAuth();

// إعداد استجابة JSON
header('Content-Type: application/json');

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $userId = getCurrentUserId();
    $conn = connectDB();
    $response = ['success' => false, 'message' => 'No changes were made'];
    
    // جمع البيانات المرسلة
    $name = isset($_POST['name']) ? trim($_POST['name']) : null;
    
    // التحقق من وجود بيانات للتحديث
    if ($name) {
        // تحديد الجدول والحقل المناسب بناءً على دور المستخدم
        if ($_SESSION['role'] == 'student') {
            $stmt = $conn->prepare("UPDATE Students SET name = ? WHERE student_id = ?");
        } else if ($_SESSION['role'] == 'professor') {
            $stmt = $conn->prepare("UPDATE Professors SET name = ? WHERE professor_id = ?");
        }
        
        if (isset($stmt)) {
            $stmt->bind_param("si", $name, $userId);
            
            if ($stmt->execute()) {
                // نجاح تحديث البيانات
                $response = [
                    'success' => true, 
                    'message' => 'تم تحديث البيانات بنجاح'
                ];
            } else {
                // فشل في تحديث البيانات
                $response = [
                    'success' => false, 
                    'message' => 'حدث خطأ أثناء تحديث البيانات: ' . $conn->error
                ];
            }
        } else {
            $response = [
                'success' => false, 
                'message' => 'نوع المستخدم غير معروف'
            ];
        }
    }
    
    // إرسال الاستجابة
    echo json_encode($response);
    exit();
}
?>
