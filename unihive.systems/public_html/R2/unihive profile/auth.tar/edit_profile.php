<?php
// Include auth file
require_once "auth.php";

// Check if user is logged in
checkLogin();

// Define variables and initialize with empty values
$name = $email = $department = "";
$name_err = $email_err = $department_err = "";
$success_msg = "";

// Get user data
$userData = getUserData($_SESSION["id"]);
if($userData) {
    $name = $userData["name"];
    $email = $userData["email"];
    $department = $userData["department"];
}

// Processing form data when form is submitted
if($_SERVER["REQUEST_METHOD"] == "POST"){
    
    // Validate name
    if(empty(trim($_POST["name"]))){
        $name_err = "Please enter your name.";
    } else {
        $name = trim($_POST["name"]);
    }
    
    // Validate email
    if(empty(trim($_POST["email"]))){
        $email_err = "Please enter your email.";
    } else {
        $email = trim($_POST["email"]);
    }
    
    // Validate department
    if(empty(trim($_POST["department"]))){
        $department_err = "Please enter your department.";
    } else {
        $department = trim($_POST["department"]);
    }
    
    // Check input errors before updating the database
    if(empty($name_err) && empty($email_err) && empty($department_err)){
        // Prepare an update statement
        $sql = "UPDATE users SET name = ?, email = ?, department = ? WHERE id = ?";
        
        if($stmt = mysqli_prepare($conn, $sql)){
            // Bind variables to the prepared statement as parameters
            mysqli_stmt_bind_param($stmt, "sssi", $name, $email, $department, $_SESSION["id"]);
            
            // Attempt to execute the prepared statement
            if(mysqli_stmt_execute($stmt)){
                $success_msg = "Profile updated successfully!";
            } else{
                echo "Oops! Something went wrong. Please try again later.";
            }

            // Close statement
            mysqli_stmt_close($stmt);
        }
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href="https://fonts.googleapis.com/css2?family=Roboto+Condensed:wght@100..700&display=swap" rel="stylesheet">
    <link href='https://unpkg.com/boxicons@2.1.4/css/boxicons.min.css' rel='stylesheet'>
    <link rel="stylesheet" href="style.css">
    <title>Edit Profile - UniHive</title>
    <link rel="icon" type="image/png" href="images/logo_blue.png">
</head>
<body>
    <section class="navbar">
        <div class="navbar_container">
          <nav>
            <div class="logo">
              <div class="logo_image">
                <img src="images/logo.png" alt="" />
              </div>
            <div class="div">
              <button id="menu-toggle">
                <i class='bx bx-menu'></i>
            </button>
            <div id="mean" class="mean" >
                <ul>
                <li><a href="#">  <i class='bx bxs-dashboard'></i>       <p>Dashbord</p> </a>       </li>
                <li><a href="#">    <i class='bx bx-library'></i>    <p>Library</p> </a>       </li>   
                <li><a href="#">  <i class='bx bx-question-mark'></i>   <p>Quizzes</p> </a>       </li>   
                <li><a href="#">    <i class='bx bxs-videos' ></i>        <p>Courses</p>  </a>       </li>   
                <li><a href="#">  <i class='bx bxs-file-blank'></i>    <p>Sheets</p>   </a>       </li>   
                <li><a href="#">     <i class='bx bxs-video'></i>      <p>Meeting</p>    </a>       </li>   
                <li><a href="#">    <i class='bx bxs-message-rounded-dots' ></i>      <p>Chat</p>   </a>       </li>   
                <li><a href="#">    <i class='bx bxs-calendar'></i>  <p >Calender</p>    </a>     </li>   

            </ul>
               </div> 
            </div>
            </div>
            <div class="user">
              <div class="user_notifications icon">
                <svg
                  width="27"
                  height="35"
                  viewBox="0 0 40 40"
                  fill="none"
                  xmlns="http://www.w3.org/2000/svg"
                >
                  <path
                    fill-rule="evenodd"
                    clip-rule="evenodd"
                    d="M5.10142 13.8514C5.10142 10.1777 6.67109 6.6546 9.46513 4.05697C12.2592 1.45934 16.0487 0 20.0001 0C23.9515 0 27.741 1.45934 30.535 4.05697C33.3291 6.6546 34.8987 10.1777 34.8987 13.8514V15.3904C34.8987 19.7469 36.6645 23.7156 39.5736 26.7177C39.7548 26.9044 39.8841 27.1296 39.95 27.3735C40.016 27.6174 40.0167 27.8726 39.952 28.1168C39.8873 28.361 39.7592 28.5867 39.579 28.7742C39.3987 28.9618 39.1718 29.1054 38.9181 29.1925C35.5101 30.3622 31.9433 31.224 28.255 31.7432C28.3381 32.7982 28.1863 33.8579 27.809 34.8559C27.4318 35.854 26.8373 36.769 26.0626 37.5438C25.288 38.3186 24.3498 38.9367 23.3067 39.3593C22.2636 39.7819 21.1379 40 20.0001 40C18.8622 40 17.7366 39.7819 16.6935 39.3593C15.6504 38.9367 14.7122 38.3186 13.9375 37.5438C13.1629 36.769 12.5683 35.854 12.1911 34.8559C11.8139 33.8579 11.6621 32.7982 11.7451 31.7432C8.10687 31.2306 4.53414 30.3753 1.08209 29.1904C0.828555 29.1034 0.601793 28.96 0.421607 28.7728C0.241422 28.5855 0.113293 28.36 0.0484117 28.1161C-0.0164697 27.8722 -0.0161307 27.6172 0.0493995 27.3735C0.11493 27.1297 0.243658 26.9046 0.424341 26.7177C3.44117 23.6123 5.10821 19.5749 5.10142 15.3904V13.8514ZM15.0383 32.1146C15.01 32.7368 15.1175 33.3578 15.3541 33.9404C15.5907 34.5229 15.9517 35.055 16.4152 35.5045C16.8787 35.954 17.4353 36.3117 18.0513 36.5561C18.6674 36.8004 19.3303 36.9264 20.0001 36.9264C20.6699 36.9264 21.3328 36.8004 21.9488 36.5561C22.5649 36.3117 23.1215 35.954 23.585 35.5045C24.0485 35.055 24.4094 34.5229 24.6461 33.9404C24.8827 33.3578 24.9901 32.7368 24.9619 32.1146C21.6607 32.3911 18.3395 32.3911 15.0383 32.1146Z"
                    fill="#FFFBFB"
                  />
                </svg>
              </div>
              <div class="user_profile icon">
                <svg
                  id="userIcon"
                  width="30"
                  viewBox="0 0 87 90"
                  fill="none"
                  stroke="currentcolor"
                  stroke-width="5"
                  xmlns="http://www.w3.org/2000/svg"
                >
                  <path
                    fill-rule="evenodd"
                    clip-rule="evenodd"
                    d="M73.3888 77.3527C77.6683 73.1998 81.0775 68.1845 83.4058 62.6169C85.734 57.0493 86.9318 51.0476 86.925 44.983C86.925 20.4218 67.6475 0.512939 43.8653 0.512939C20.0831 0.512939 0.805571 20.4218 0.805571 44.983C0.798776 51.0476 1.99652 57.0493 4.32476 62.6169C6.65301 68.1845 10.0623 73.1998 14.3418 77.3527C22.3219 85.1378 32.8877 89.4683 43.8653 89.4531C54.8429 89.4683 65.4086 85.1378 73.3888 77.3527ZM18.0074 71.4917C21.108 67.4855 25.0427 64.2521 29.5193 62.0317C33.9958 59.8114 38.8992 58.661 43.8653 58.6661C48.8313 58.661 53.7347 59.8114 58.2113 62.0317C62.6878 64.2521 66.6225 67.4855 69.7232 71.4917C66.3403 75.0206 62.3127 77.8207 57.8739 79.7295C53.4351 81.6383 48.6735 82.618 43.8653 82.6115C39.057 82.618 34.2954 81.6383 29.8566 79.7295C25.4178 77.8207 21.3902 75.0206 18.0074 71.4917ZM60.4267 31.2999C60.4267 35.8361 58.6818 40.1866 55.576 43.3942C52.4701 46.6018 48.2576 48.4038 43.8653 48.4038C39.4729 48.4038 35.2604 46.6018 32.1546 43.3942C29.0487 40.1866 27.3038 35.8361 27.3038 31.2999C27.3038 26.7637 29.0487 22.4132 32.1546 19.2056C35.2604 15.998 39.4729 14.196 43.8653 14.196C48.2576 14.196 52.4701 15.998 55.576 19.2056C58.6818 22.4132 60.4267 26.7637 60.4267 31.2999Z"
                    fill="white"
                  />
                </svg>
              </div>
            </div>
          </nav>
        </div>
      </section>
      
      <section>
        <header>
          <h1>Edit Profile</h1>
        </header>
      </section>
      
      <section>
        <main>
          <div class="profile_container">
            <div class="edit_profile_form">
              <?php 
              if(!empty($success_msg)){
                  echo '<div class="alert alert-success">' . $success_msg . '</div>';
              }        
              ?>
              
              <form action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>" method="post">
                  <div class="form-group">
                      <label>Name</label>
                      <input type="text" name="name" class="form-control <?php echo (!empty($name_err)) ? 'is-invalid' : ''; ?>" value="<?php echo $name; ?>">
                      <span class="invalid-feedback"><?php echo $name_err; ?></span>
                  </div>    
                  <div class="form-group">
                      <label>Email</label>
                      <input type="email" name="email" class="form-control <?php echo (!empty($email_err)) ? 'is-invalid' : ''; ?>" value="<?php echo $email; ?>">
                      <span class="invalid-feedback"><?php echo $email_err; ?></span>
                  </div>
                  <div class="form-group">
                      <label>Department</label>
                      <input type="text" name="department" class="form-control <?php echo (!empty($department_err)) ? 'is-invalid' : ''; ?>" value="<?php echo $department; ?>">
                      <span class="invalid-feedback"><?php echo $department_err; ?></span>
                  </div>
                  <div class="form-group">
                      <input type="submit" class="btn btn-primary" value="Update Profile">
                      <a href="profile.php" class="btn btn-secondary">Cancel</a>
                  </div>
              </form>
            </div>
          </div>
        </main>
      </section>
      
      <div class="footer">
        <div class="footer_container">
          <div class="footer_content">
            <a href="#" class="website">www.unihive.com</a>
            <div class="footer_links">
              <a href="#">
                <svg
                  width="20"
                  height="20"
                  viewBox="0 0 39 40"
                  fill="none"
                  xmlns="http://www.w3.org/2000/svg"
                >
                  <path
                    d="M0 5.625C0 4.13316 0.582235 2.70242 1.61862 1.64752C2.65501 0.592632 4.06065 0 5.52632 0H8.05368C9.6379 0 11.0195 1.09875 11.4045 2.6625L13.44 10.9556C13.6049 11.6269 13.5716 12.3327 13.3442 12.9848C13.1168 13.6369 12.7054 14.2061 12.1616 14.6213L9.77974 16.44C9.53105 16.6294 9.47763 16.9069 9.54763 17.1C10.5873 19.9778 12.229 22.5913 14.3591 24.7595C16.4892 26.9276 19.0569 28.5987 21.8842 29.6569C22.0739 29.7281 22.3447 29.6737 22.5326 29.4206L24.3195 26.9963C24.7273 26.4427 25.2866 26.024 25.9272 25.7925C26.5678 25.561 27.2613 25.5271 27.9208 25.695L36.0684 27.7669C37.6047 28.1588 38.6842 29.565 38.6842 31.1794V33.75C38.6842 35.2418 38.102 36.6726 37.0656 37.7275C36.0292 38.7824 34.6236 39.375 33.1579 39.375H29.0132C12.9905 39.375 0 26.1525 0 9.84375V5.625Z"
                    fill="#7B90A7"
                  />
                </svg>
              </a>
              <a href="#"
                ><svg
                  width="23"
                  height="20"
                  viewBox="0 0 23 42"
                  fill="none"
                  xmlns="http://www.w3.org/2000/svg"
                >
                  <path
                    d="M16.6897 0C10.8804 0 7.4734 3.05281 7.4734 10.0083V16.1278H0.10498V23.4586H7.4734V41.0526H14.8418V23.4586H20.7366L22.2102 16.1278H14.8418V11.2482C14.8418 8.6282 15.7006 7.33083 18.172 7.33083H22.2102V0.300678C21.5117 0.206844 19.4764 0 16.6897 0Z"
                    fill="#7B90A7"
                  />
                </svg>
              </a>
              <a href="#"
                ><svg
                  width="20"
                  height="20"
                  viewBox="0 0 39 39"
                  fill="none"
                  xmlns="http://www.w3.org/2000/svg"
                >
                  <path
                    d="M38.9053 20.6763C39.1728 17.2776 38.529 13.869 37.0402 10.802C34.5757 13.1435 31.6626 14.9617 28.4763 16.1467C28.7325 19.2914 28.5906 22.4559 28.054 25.5651C31.9312 24.5886 35.605 22.9335 38.9053 20.6763ZM24.9178 26.1987C25.5482 23.1849 25.7686 20.0998 25.573 17.027C23.6941 17.475 21.7342 17.7118 19.7191 17.7118C17.704 17.7118 15.7441 17.475 13.8652 17.027C13.6742 20.0997 13.8946 23.1843 14.5204 26.1987C17.9661 26.7268 21.4721 26.7268 24.9178 26.1987ZM15.3217 29.2954C18.2431 29.641 21.1951 29.641 24.1165 29.2954C23.1124 32.5275 21.6302 35.591 19.7191 38.3842C17.8079 35.591 16.3257 32.5275 15.3217 29.2954ZM11.3842 25.5671C10.8447 22.4569 10.7028 19.2907 10.9619 16.1447C7.77493 14.96 4.86105 13.1418 2.39608 10.8C0.907558 13.8678 0.264392 17.2771 0.532922 20.6763C3.8332 22.9335 7.50698 24.5906 11.3842 25.5671ZM38.1849 24.6237C37.1884 28.0005 35.2859 31.0399 32.684 33.4118C30.082 35.7838 26.8801 37.3977 23.4257 38.0783C25.1557 35.1696 26.476 32.0361 27.3494 28.7664C31.1576 27.9683 34.8149 26.5706 38.1849 24.6257V24.6237ZM1.25332 24.6237C4.57305 26.5401 8.22042 27.9553 12.0888 28.7664C12.9622 32.0361 14.2826 35.1696 16.0125 38.0783C12.5584 37.3978 9.35656 35.7842 6.75465 33.4127C4.15274 31.0411 2.25013 28.0021 1.25332 24.6257V24.6237ZM23.4257 0.303947C28.3159 1.26515 32.6429 4.08519 35.4967 8.17105C33.3902 10.2994 30.8754 11.9804 28.1033 13.1132C27.3564 8.58911 25.7699 4.24468 23.4257 0.303947ZM19.7191 0C22.5995 4.20809 24.492 9.01256 25.2553 14.0546C23.4849 14.5086 21.6296 14.7513 19.7191 14.7513C17.8086 14.7513 15.9533 14.5105 14.1829 14.0546C14.9461 9.01254 16.8386 4.20806 19.7191 0ZM16.0125 0.303947C13.6682 4.24466 12.0817 8.5891 11.3349 13.1132C8.56277 11.9805 6.04801 10.2995 3.94147 8.17105C6.7955 4.08579 11.1225 1.26446 16.0125 0.303947Z"
                    fill="#7B90A7"
                  />
                </svg>
              </a>
            </div>
          </div>
        </div>
      </div>
    
    <script src="./script.js"></script>
</body>
</html>