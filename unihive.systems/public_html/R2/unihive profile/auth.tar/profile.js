document.addEventListener('DOMContentLoaded', function() {
    // تحميل بيانات المستخدم عند تحميل الصفحة
    loadUserProfile();
    
    // إضافة مستمعات الأحداث للأزرار
    const editProfileButton = document.querySelector('.profile_settings_edit');
    if (editProfileButton) {
        editProfileButton.addEventListener('click', showEditProfileForm);
    }
    
    const logoutButton = document.querySelector('.profile_settings_logout');
    if (logoutButton) {
        logoutButton.addEventListener('click', function() {
            window.location.href = 'logout.php';
        });
    }
    
    // اضف مستمعات أخرى حسب الحاجة
});

// دالة لتحميل بيانات المستخدم
function loadUserProfile() {
    fetch('get_profile.php', {
        method: 'GET',
        headers: {
            'X-Requested-With': 'XMLHttpRequest'
        }
    })
    .then(response => response.json())
    .then(data => {
        // عرض بيانات المستخدم في الصفحة
        displayUserData(data);
    })
    .catch(error => {
        console.error('Error loading profile data:', error);
    });
}

// دالة لعرض بيانات المستخدم
function displayUserData(userData) {
    // اسم المستخدم
    const userNameElement = document.querySelector('.profile_title h3');
    if (userNameElement && userData.name) {
        userNameElement.textContent = userData.name;
    }
    
    // المستوى الدراسي
    const userLevelElement = document.querySelector('.profile_title p');
    if (userLevelElement && userData.level) {
        userLevelElement.textContent = userData.level;
    }
    
    // صورة المستخدم
    const userImageElement = document.querySelector('.profile_user_image');
    if (userImageElement && userData.profile_image) {
        userImageElement.src = userData.profile_image;
    }
    
    // أي بيانات إضافية حسب تصميم الصفحة
}

// دالة لإظهار نموذج تعديل البيانات
function showEditProfileForm() {
    // يمكن إظهار نافذة منبثقة لتعديل البيانات أو التوجيه لصفحة أخرى
    // مثال لنافذة منبثقة بسيطة
    const formHTML = `
        <div class="edit-form-overlay">
            <div class="edit-form-container">
                <h3>تعديل البيانات الشخصية</h3>
                <form id="updateProfileForm">
                    <div class="form-group">
                        <label for="name">الاسم</label>
                        <input type="text" id="name" name="name" required>
                    </div>
                    <div class="form-group">
                        <label for="email">البريد الإلكتروني</label>
                        <input type="email" id="email" name="email" required>
                    </div>
                    <div class="form-group">
                        <label for="phone">رقم الهاتف</label>
                        <input type="text" id="phone" name="phone">
                    </div>
                    <div class="form-group">
                        <label for="profile_image">صورة البروفايل</label>
                        <input type="file" id="profile_image" name="profile_image">
                    </div>
                    <div class="form-actions">
                        <button type="submit" class="btn-save">حفظ</button>
                        <button type="button" class="btn-cancel" onclick="closeEditForm()">إلغاء</button>
                    </div>
                </form>
            </div>
        </div>
    `;
    
    // إضافة النموذج للصفحة
    const formContainer = document.createElement('div');
    formContainer.id = 'editFormContainer';
    formContainer.innerHTML = formHTML;
    document.body.appendChild(formContainer);
    
    // تحميل بيانات المستخدم في النموذج
    loadUserDataToForm();
    
    // إضافة مستمع الحدث لإرسال النموذج
    document.getElementById('updateProfileForm').addEventListener('submit', submitProfileUpdate);
}

// دالة لإغلاق نموذج التعديل
function closeEditForm() {
    const formContainer = document.getElementById('editFormContainer');
    if (formContainer) {
        formContainer.remove();
    }
}

// دالة لتحميل بيانات المستخدم في نموذج التعديل
function loadUserDataToForm() {
    fetch('get_profile.php', {
        headers: {
            'X-Requested-With': 'XMLHttpRequest'
        }
    })
    .then(response => response.json())
    .then(data => {
        document.getElementById('name').value = data.name || '';
        document.getElementById('email').value = data.email || '';
        document.getElementById('phone').value = data.phone || '';
    })
    .catch(error => {
        console.error('Error loading user data for form:', error);
    });
}

// دالة لإرسال بيانات التعديل
function submitProfileUpdate(event) {
    event.preventDefault();
    
    const formData = new FormData(document.getElementById('updateProfileForm'));
    
    // إرسال بيانات النموذج باستثناء الصورة
    fetch('update_profile.php', {
        method: 'POST',
        body: formData
    })
    .then(response => response.json())
    .then(data => {
        if (data.success) {
            // إذا كان هناك صورة، قم بتحميلها
            const profileImage = document.getElementById('profile_image').files[0];
            if (profileImage) {
                uploadProfileImage(profileImage);
            } else {
                // إظهار رسالة نجاح وإغلاق النموذج
                alert(data.message);
                closeEditForm();
                // إعادة تحميل البيانات
                loadUserProfile();
            }
        } else {
            alert(data.message || 'حدث خطأ أثناء تحديث البيانات');
        }
    })
    .catch(error => {
        console.error('Error updating profile:', error);
        alert('حدث خطأ أثناء تحديث البيانات');
    });
}

// دالة لتحميل صورة البروفايل
function uploadProfileImage(file) {
    const imageFormData = new FormData();
    imageFormData.append('profile_image', file);
    
    fetch('upload_profile_image.php', {
        method: 'POST',
        body: imageFormData
    })
    .then(response => response.json())
    .then(data => {
        if (data.success) {
            // إظهار رسالة نجاح وإغلاق النموذج
            alert('تم تحديث البيانات والصورة بنجاح');
            closeEditForm();
            // إعادة تحميل البيانات وتحديث الصورة
            loadUserProfile();
        } else {
            alert(data.message || 'حدث خطأ أثناء تحميل الصورة');
        }
    })
    .catch(error => {
        console.error('Error uploading image:', error);
        alert('حدث خطأ أثناء تحميل الصورة');
    });
}

// تجهيز القائمة الجانبية
document.getElementById('menu-toggle').addEventListener('click', function() {
    document.getElementById('mean').classList.toggle('active');
});