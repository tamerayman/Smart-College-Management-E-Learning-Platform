<?php
require_once 'db_connect.php';
require_once 'auth.php';

// التحقق من تسجيل الدخول
checkAuth();

// إعداد استجابة JSON
header('Content-Type: application/json');

if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_FILES["profile_image"])) {
    $userId = getCurrentUserId();
    $uploadDir = "uploads/profile_images/";
    
    // إنشاء المجلد إذا لم يكن موجودًا
    if (!file_exists($uploadDir)) {
        mkdir($uploadDir, 0777, true);
    }
    
    $fileExtension = pathinfo($_FILES["profile_image"]["name"], PATHINFO_EXTENSION);
    $newFileName = "user_" . $userId . "_" . time() . "." . $fileExtension;
    $targetFile = $uploadDir . $newFileName;
    
    // التحقق من نوع الملف
    $allowedTypes = ["jpg", "jpeg", "png", "gif"];
    if (!in_array(strtolower($fileExtension), $allowedTypes)) {
        $response = ["success" => false, "message" => "نوع الملف غير مسموح به. الأنواع المسموحة: JPG, JPEG, PNG, GIF"];
        echo json_encode($response);
        exit();
    }
    
    // التحقق من حجم الملف (5 ميجابايت كحد أقصى)
    if ($_FILES["profile_image"]["size"] > 5 * 1024 * 1024) {
        $response = ["success" => false, "message" => "حجم الملف كبير جدًا. الحد الأقصى هو 5 ميجابايت"];
        echo json_encode($response);
        exit();
    }
    
    // تحميل الملف
    if (move_uploaded_file($_FILES["profile_image"]["tmp_name"], $targetFile)) {
        // تحديث مسار الصورة في قاعدة البيانات حسب نوع المستخدم
        $conn = connectDB();
        
        if ($_SESSION['role'] == 'student') {
            $stmt = $conn->prepare("UPDATE Students SET profile_image = ? WHERE student_id = ?");
        } else if ($_SESSION['role'] == 'professor') {
            $stmt = $conn->prepare("UPDATE Professors SET profile_image = ? WHERE professor_id = ?");
        } else {
            $stmt = $conn->prepare("UPDATE Users SET profile_image = ? WHERE user_id = ?");
        }
        
        $stmt->bind_param("si", $targetFile, $userId);
        
        if ($stmt->execute()) {
            $response = ["success" => true, "message" => "تم تحميل الصورة بنجاح", "image_path" => $targetFile];
        } else {
            $response = ["success" => false, "message" => "تم تحميل الصورة ولكن فشل تحديث قاعدة البيانات: " . $conn->error];
        }
    } else {
        $response = ["success" => false, "message" => "فشل تحميل الصورة"];
    }
    
    echo json_encode($response);
    exit();
} else {
    echo json_encode(["success" => false, "message" => "لم يتم إرسال أي ملف"]);
    exit();
}
?>